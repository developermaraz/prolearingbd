<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Offers</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Offers</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Order Id">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Code</th>
                                        <th>Discount Type</th>
                                        <th>Status</th>
                                        <th>Expire Date</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td>Md. Maraz</td>
                                        <td>laravel33</td>
                                        <td><button type="button" class="btn btn-sm btn-danger">Pending</button></td>
                                        <td>12.2-.34e32</td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger">Pending</button>
                                        </td>
                                        <td>
                                            <a href="admin-details.php" class="btn btn-warning btn-sm m-1" title="View"><i class="fas fa-desktop"></i></a>
                                            <a href="admin-details.php" class="btn btn-success btn-sm m-1" title="Make Active"><i class="fa-solid fa-check"></i></a>
                                            <a href="admin-details.php" class="btn btn-danger btn-sm m-1" title="Delete"><i class="fa-solid fa-trash-arrow-up"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>