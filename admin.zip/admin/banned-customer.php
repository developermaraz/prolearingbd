<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Banned Customer List</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Banned Customer List</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email | Mobile</th>
                                        <th>Country</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td>Maraz</td>
                                        <td>
                                            info@gmail.com
                                            <br>
                                            01648837019
                                        </td>
                                        <td>
                                            BD
                                            <br>
                                            Bangladesh
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-danger">Active</button>
                                        </td>
                                        <td>
                                            <a href="admin-details.php" class="btn btn-warning btn-sm"><i class="fas fa-desktop"></i></a>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-danger btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                    Action
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="admin-login-log.php">Login Logs</a></li>
                                                    <li><a class="dropdown-item" href="admin-email-log.php">Email Logs</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>