<?php
if (!isset($_GET['id'])) {
    header("Location: ../403.php");
    exit;
} elseif (empty($_GET['id'])) {
    header("Location: ../403.php");
    exit;
}
require('header.php');
$id = input_sanitize_process($_GET['id']);
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="main-title" style="padding-bottom: 10px;">Admin's Detail </h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="all-admin" class="btn btn-warning btn-sm"><i class="fa-solid fa-backward"></i> Back</a>
            </div>
        </div>
        <div class="row">
            <?php
            $data = getSingleAdminUserDetails($id);
            foreach ($data as $row) {
            ?>
                <div class="col-xl-3 col-lg-5 col-md-5 mb-30">
                    <div class="card  overflow-hidden main-nav--bg shadow">
                        <div class="card-body p-0 ">
                            <div class="p-3">
                                <div>
                                    <img src="img/avatar/avatar-2.svg" class="b-radius--10 w-100" alt="">
                                </div>
                                <div class="mt-4">
                                    <h4 class="main-title"><?php echo $row['name']; ?></h4>
                                    <span class="main-title">Joined At <strong><?php echo $row['created_at']; ?></strong></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card overflow-hidden main-nav--bg mt-5 shadow">
                        <div class="card-body">
                            <h5 class="mb-20 main-title">Admin Information</h5>
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">Email Status <span class="badge badge-pill bg-<?php if ($row['emailVerify'] != 0) {
                                                                                                                                                                echo 'danger';
                                                                                                                                                            } else {
                                                                                                                                                                echo 'success';
                                                                                                                                                            } ?>" style="text-align: right;"><?php if ($row['emailVerify'] != 0) {
                                                                                                                                                                                                    echo 'Unactive';
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    echo 'Active';
                                                                                                                                                                                                } ?></span></li>
                                <li class="list-group-item mt-2 d-flex justify-content-between align-items-center">Status <span class="badge badge-pill bg-<?php if ($row['status'] != 0) {
                                                                                                                                                                echo 'danger';
                                                                                                                                                            } else {
                                                                                                                                                                echo 'success';
                                                                                                                                                            } ?>" style="text-align: right;"><?php if ($row['status'] != 0) {
                                                                                                                                                                                                    echo 'Unactive';
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    echo 'Active';
                                                                                                                                                                                                } ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card shadow main-nav--bg overflow-hidden mt-5">
                        <div class="card-body">
                            <h5 class="mb-20 main-title">Admin Action</h5>
                            <button class="btn btn-primary btn-shadow mt-3 w-100 btn-md main-title">Login Logs</button>
                            <button class="btn btn-warning btn-shadow mt-3 w-100 btn-md main-title">Send Email</button>
                            <button class="btn btn-danger btn-shadow mt-3 w-100 btn-md main-title">Email Log</button>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-7 col-md-7 mb-30">
                    <div class="card main-nav--bg shadow">
                        <div class="card-body">
                            <h5 class="card-title border-bottom pb-2 main-title">Information Of <?php echo $row['name']; ?></h5>
                            <form action="" method="POST">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="main-title">Full Name</label>
                                            <input type="text" name="fullName" placeholder="Full Name" class="form-control mt-2 border-warning" value="<?php echo $row['name']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">Email Address</label>
                                            <input type="email" name="email" placeholder="Email Address" readonly class="form-control mt-2 border-warning" value="<?php echo $row['email']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">Mobile</label>
                                            <input type="text" name="mobile" placeholder="Mobile" readonly class="form-control mt-2 border-warning" value="<?php echo $row['phone']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">Address</label>
                                            <input type="text" name="address" placeholder="Address" class="form-control mt-2 border-warning" value="<?php echo $row['address']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">City</label>
                                            <input type="text" name="city" placeholder="City" class="form-control mt-2 border-warning" value="<?php echo $row['city']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">State</label>
                                            <input type="text" name="state" placeholder="State" class="form-control mt-2 border-warning" value="<?php echo $row['state']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">Zip/Postal</label>
                                            <input type="text" name="zipPostal" placeholder="Zip/Postal" class="form-control mt-2 border-warning" value="<?php echo $row['zip-postal']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <div class="form-group">
                                            <label class="main-title">Country</label>
                                            <input type="text" name="country" placeholder="Country" value="<?php echo $row['country']; ?>" class="form-control mt-2 border-warning">
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <div class="form-group">
                                            <label class="main-title">Role</label>
                                            <select name="role" class="form-select border-warning" id="">
                                                <option value="">Select Status</option>
                                                <option value="admin" <?php if ($row['role'] == 0) {
                                                                            echo 'selected';
                                                                        } ?>>Admin</option>
                                                <option value="moderator" <?php if ($row['role'] != 0) {
                                                                                echo 'selected';
                                                                            } ?>>Moderator</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <div class="form-group">
                                            <label class="main-title">Status</label>
                                            <select name="status" class="form-select border-warning" id="">
                                                <option value="">Select Status</option>
                                                <option value="active" <?php if ($row['status'] == 0) {
                                                                            echo 'selected';
                                                                        } ?>>Active</option>
                                                <option value="inactive" <?php if ($row['status'] != 0) {
                                                                                echo 'selected';
                                                                            } ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                    <input type="text" name="id" style="display: none;" value="<?php echo $id; ?>">
                                    <div class="col-md-12">
                                        <button type="submit" name="UpdateAdminInformation" class="btn btn-warning btn-sm w-100 mt-3">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        </div>
    <?php } ?>
    </div>
</main>
<?php
require('footer.php');
?>