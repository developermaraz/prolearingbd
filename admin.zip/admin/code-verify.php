<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Code Verify</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <form action="">
                                <div class="row">
                                    <div class="col-md-4">
                                        <p class="main-title mb-20"><b>Image</b></p>
                                        <div style="height: 310px; border: none; box-shadow: 0px 0px 13px 0px #8b8b8b; border-radius: 20px;">
                                            <img width="100%" height="310px" style="border-radius: 20px;" src="../images/teammates/teammate-1.jpg" alt="">
                                        </div>
                                        <button class="mt-5 btn btn-sm btn-warning w-100">Image</button>
                                        <p class="main-title m-2">Supported files: <b>jpeg, jpg, png.</b> | Will be resized to: <b>600x600 px.</b></p>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="" class="main-title">Title</label>
                                            <input type="text" name="title" class="form-control border-warning" placeholder="Verify Your Code">
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="main-title mt-5">Discription</label>
                                            <textarea name="" id="" class="form-control border-warning" rows="10">We sent you a verification code. Please allow several minutes for this code to arrive. This code will be valid for 15 minutes after you request it.</textarea>
                                        </div>
                                    </div>
                                    <button class="btn btn-warning btn-sm w-100 mt-5">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<?php
require('footer.php');
?>