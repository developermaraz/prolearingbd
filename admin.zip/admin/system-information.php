<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 30px;">System Information</h2>
        <div class="row" style="box-shadow: 0px 0px 11px 4px wheat; border-radius: 12px;">
            <div class="col-md-12 p-3">
                <table class="table table-bordered main-title">
                    <tr>
                        <th>PHP Version</th>
                        <td>8.1.18</td>
                    </tr>
                    <tr>
                        <th>Server Software</th>
                        <td>Apache</td>
                    </tr>
                    <tr>
                        <th>Server IP Address</th>
                        <td>104.161.21.138</td>
                    </tr>
                    <tr>
                        <th>Server Protocol</th>
                        <td>HTTP/2.0</td>
                    </tr>
                    <tr>
                        <th>HTTP Host</th>
                        <td>ecommerce.developermaraz.com</td>
                    </tr>
                    <tr>
                        <th>Database Port</th>
                        <td>3306</td>
                    </tr>
                    <tr>
                        <th>Timezone</th>
                        <td>Asia/Kolkata</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>