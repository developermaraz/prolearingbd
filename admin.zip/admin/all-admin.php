<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Admin List</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">All Admin List</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                                <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="btn btn-success btn-sm text-white">Add Admin</button>
                            </div>
                            <div class="col-md-4">
                                <input type="text" id="SearchInput" class="form-control border-danger main-nav--bg main-title" onkeyup="searchFun()" placeholder="Search Mobile / Email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table id="AllAdminTable" class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email | Mobile</th>
                                        <th>Email Status</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>

                                    <?php
                                    $data = getAdminUserDetails('ALL');
                                    if(empty($data)){
                                        echo "<tr>
                                                <td colspan='6' class='bg-danger text-white'>No Data Found</td>
                                    </tr>";
                                    }
                                    $sl = 0;
                                    foreach ($data as $row) {
                                        $id = $row['id'];
                                    ?>
                                        <tr>
                                            <td><?php echo $sl++ ?></td>
                                            <td><?php echo $row['name']; ?></td>
                                            <td>
                                                <?php echo $row['email']; ?>
                                                <br>
                                                <?php echo $row['phone']; ?>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-<?php if ($row['emailVerify'] == 0) {
                                                                                            echo 'success';
                                                                                        } else {
                                                                                            echo 'danger';
                                                                                        } ?> btn-sm"><?php if ($row['emailVerify'] == 0) {
                                                                                                            echo 'Verified';
                                                                                                        } else {
                                                                                                            echo 'Unverified';
                                                                                                        } ?></button>
                                            </td>
                                            <td>
                                                <button id="status" class=" btn btn-sm btn-<?php if ($row['status'] == 0) {
                                                                                                echo 'success';
                                                                                            } else {
                                                                                                echo 'danger';
                                                                                            } ?>" onclick='activeDeactiveAdmin(<?php echo "$id, $sl";; ?>)'><?php if ($row['status'] == 0) {
                                                                                                                                                                echo 'Active';
                                                                                                                                                            } else {
                                                                                                                                                                echo 'Inactive';
                                                                                                                                                            } ?></button>
                                            </td>
                                            <td>
                                                <a href="admin-details.php?id=<?php echo base64_encode($id); ?>" class="btn btn-warning btn-sm"><i class="fas fa-desktop"></i></a>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-danger btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                        Action
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="admin-login-log?email=<?php echo base64_encode($row['email']); ?>">Login Logs</a></li>
                                                        <li><a class="dropdown-item" href="admin-email-log?email=<?php echo base64_encode($row['email']); ?>">Email Logs</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="NoDataFound" style="display: none;" colspan="6" class="bg-danger text-white">No Data Found</td>
                                        </tr>
                                        <!-- Modal -->
                                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel">Add Admin</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <form id="AddNewAdminForm">
                                                                    <div class="form-group">
                                                                        <label for="">Name <span class="text-danger">*</span> </label>
                                                                        <input type="text" id="AddNewFullName" class="form-control border-danger" name="name" placeholder="Full Name">
                                                                    </div>
                                                                    <div class="form-group mt-3">
                                                                        <label for="">Email <span class="text-danger">*</span> </label>
                                                                        <input type="email" id="AddNewEmail" class="form-control border-danger" name="email" placeholder="Email Address">
                                                                    </div>
                                                                    <div class="form-group mt-3">
                                                                        <label for="">Role <span class="text-danger">*</span></label>
                                                                        <select name="role" class="form-select border-danger" id="AddNewRole">
                                                                            <option value="">Select Role</option>
                                                                            <option value="0">Admin</option>
                                                                            <option value="1">Moderator</option>
                                                                        </select>
                                                                    </div>
                                                                    <button type="button" onclick="addNewAdminUser()" class="btn btn-sm btn-warning w-100 mt-3">Submit</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    
</script>
<?php
require('footer.php');
?>