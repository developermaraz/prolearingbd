<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" style="overflow: scroll; scroll-behavior: smooth;" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Product Categories</h2>
        <div class="row">
            <div class="row">
                <div class="col-md-12 border border-3 rounded-2 shadow bg-white" style="padding: 10px;">
                    <a href="add-category" class="btn btn-sm btn-success">Add Category</a>
                    <a href="add-subcategory" class="btn btn-sm btn-warning">Add Sub Category</a>
                    <a href="add-sub-child-category" class="btn btn-sm btn-danger">Add Sub Child Category</a>
                </div>
            </div>
            <div class="col-md-12 mt-4 border border-3 rounded-2 shadow main-nav--bg" style="padding: 10px;">
                <div class="card main-nav--bg">
                    <div class="card-header bg-warning">
                        <div class="row">
                            <div class="col-md-6 align-middle">
                                <h5 class="main-title ">Category</h5>
                            </div>
                            <div class="col-md-6 text-end align-middle">
                                <input type="text" id="categoryPCP" oninput="SearchCategoryNameInProductCategories()" class="form-control" placeholder="Search">
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="categoryTablePCP" class="table table-bordered main-title text-center">
                            <tr>
                                <th>#</th>
                                <th>Category Name</th>
                                <th>Total Product</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $sl = 0;
                            $data = getProductCategory();
                            foreach ($data as $row) {
                                $id = $row['id'];
                            ?>
                                <tr id="row_<?php echo $id; ?>">
                                    <td><?php echo $sl++; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo '0' ?></td>
                                    <td><button id="CategoriesStatus" onclick='activeDeactiveProductCategory(<?php echo "$id, $sl"; ?>)' class="btn btn-<?php if ($row['status'] != 0) {
                                                                                                                                                            echo 'danger';
                                                                                                                                                        } else {
                                                                                                                                                            echo 'success';
                                                                                                                                                        } ?> btn-sm"><?php if ($row['status'] != 0) {
                                                                                                                                                                            echo 'Deactive';
                                                                                                                                                                        } else {
                                                                                                                                                                            echo 'Active';
                                                                                                                                                                        } ?></button></td>
                                    <td>
                                        <a href="" title="View" class="btn btn-sm btn-success"><i class="fas fa-desktop"></i></a>
                                        <a href="edit-category.php?id=<?php echo base64_encode($id);?>" title="Edit" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <button type="button" onclick="deleteFunctionForProductCateogry(<?php echo $id; ?>)" title="Delete" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td id="NoDataFoundCategoryTablePCP" style="display: none;" colspan="6" class="bg-danger text-white">No Data Found</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-4 border border-3 rounded-2 shadow main-nav--bg" style="padding: 10px;">
                <div class="card main-nav--bg mt-4">
                    <div class="card-header bg-info">
                        <div class="row">
                            <div class="col-md-6 align-middle">
                                <h5 class="main-title ">Sub Category</h5>
                            </div>
                            <div class="col-md-6 text-end align-middle">
                                <input oninput="SearchSubCategoryNameInProductCategories()" id="subCategoryPCP" type="text" class="form-control" placeholder="Search">
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="subCategoryTablePCP" class="table table-bordered main-title text-center">
                            <tr>
                                <th>#</th>
                                <th>Category Name</th>
                                <th>Sub Category Name</th>
                                <th>Total Product</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $sl = 0;
                            $data = getAllProductSubCategory();
                            foreach ($data as $row) {
                                $id = $row['id'];
                                $category = base64_encode($row['category']);
                            ?>
                                <tr id="SubCateRow_<?php echo $id; ?>">
                                    <td><?php echo $sl++; ?></td>
                                    <td><?php echo getCategoryNameBySubCateId($category); ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo '0' ?></td>
                                    <td><button id="SubCategoriesStatus" onclick='activeDeactiveProductSubCategory(<?php echo "$id, $sl"; ?>)' class="btn btn-<?php if ($row['status'] != 0) {
                                                                                                                                                                    echo 'danger';
                                                                                                                                                                } else {
                                                                                                                                                                    echo 'success';
                                                                                                                                                                } ?> btn-sm"><?php if ($row['status'] != 0) {
                                                                                                                                                                                    echo 'Deactive';
                                                                                                                                                                                } else {
                                                                                                                                                                                    echo 'Active';
                                                                                                                                                                                } ?></button></td>
                                    <td>
                                        <a href="" title="View" class="btn btn-sm btn-success"><i class="fas fa-desktop"></i></a>
                                        <a href="edit-sub-category.php" title="Edit" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <button type="button" onclick="deleteFunctionForProductSubCateogry(<?php echo $id; ?>)" title="Delete" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td id="NoDataFoundSubCategoryTablePCP" style="display: none;" colspan="6" class="bg-danger text-white">No Data Found</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-4 border border-3 rounded-2 shadow main-nav--bg" style="padding: 10px;">
                <div class="card main-nav--bg mt-4">
                    <div class="card-header bg-secondary">
                        <div class="row">
                            <div class="col-md-6 align-middle">
                                <span class="main-title">Sub Child Category</span>
                            </div>
                            <div class="col-md-6 text-end align-middle">
                                <input id="ChildSubCategoryPCP" oninput="SearchChildSubCategoryNameInProductCategories()" type="text" class="form-control" placeholder="Search">
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="ChildSubCategoryTablePCP" class="table table-bordered main-title text-center">
                            <tr>
                                <th>#</th>
                                <th>Category Name</th>
                                <th>Sub Name</th>
                                <th>Child Name</th>
                                <th>Total Product</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $sl = 0;
                            $data = getAllProductChildSubCategory();
                            foreach ($data as $row) {
                                $id = $row['id'];
                                $category = base64_encode($row['category']);
                                $subcategory = base64_encode($row['subcategory']);
                            ?>
                                <tr id="SubChildRow_<?php echo $id; ?>">
                                    <td><?php echo $sl++; ?></td>
                                    <td><?php echo getCategoryNameBySubCateId($category); ?></td>
                                    <td><?php echo getSubCategoryNameByChildSubCateId($subcategory); ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo '0' ?></td>
                                    <td><button id="SubChildCategoriesStatus" onclick='activeDeactiveProductSubChildCategory(<?php echo "$id, $sl"; ?>)' class="btn btn-<?php if ($row['status'] != 0) {
                                                                                                                                                                            echo 'danger';
                                                                                                                                                                        } else {
                                                                                                                                                                            echo 'success';
                                                                                                                                                                        } ?> btn-sm"><?php if ($row['status'] != 0) {
                                                                                                                                                                                            echo 'Deactive';
                                                                                                                                                                                        } else {
                                                                                                                                                                                            echo 'Active';
                                                                                                                                                                                        } ?></button></td>
                                    <td>
                                        <a href="" title="View" class="btn btn-sm btn-success"><i class="fas fa-desktop"></i></a>
                                        <a href="" title="Edit" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                        <button type="button" onclick="deleteFunctionForProductSubChildCateogry(<?php echo $id; ?>)" title="Delete" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td id="NoDataFoundChildSubCategoryTablePCP" style="display: none;" colspan="7" class="bg-danger text-white">No Data Found</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>

<script type="text/javascript">
    
    
    
</script>
<?php
require('footer.php');
?>