<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Customer Email Send</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Customer Email Send</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="">
                                    <div class="form-group mt-2">
                                        <label for="" class="main-title">To</label>
                                        <input type="text" class="form-control border-warning" placeholder="Customer Email Address">
                                    </div>
                                    <div class="form-group mt-2">
                                        <label for="" class="main-title">Message</label>
                                        <textarea name="" class="form-control border-warning" id="" placeholder="Message" cols="30" rows="10"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100 mt-2">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>