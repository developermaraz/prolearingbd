
<?php
if(isset($_SESSION['AlertMess']) && !empty($_SESSION['AlertMess'])){
    ?>
    <script>
        document.getElementById('notificationSound').play();
    </script>
    <?php
    $type = $_SESSION['AlertMess']["type"];
    $mess = $_SESSION['AlertMess']["mess"];
    AlertMessage($type, $mess);
    unset($_SESSION['AlertMess']);
}
?>
<!-- ! Footer -->
<footer class="footer">
    <div class="container footer--flex">
        <div class="footer-start">
            <p>2021 © Elegant Dashboard - <a href="elegant-dashboard.com" target="_blank" rel="noopener noreferrer">elegant-dashboard.com</a></p>
        </div>
        <ul class="footer-end">
            <li><a href="##">About</a></li>
            <li><a href="##">Support</a></li>
            <li><a href="##">Puchase</a></li>
        </ul>
</footer>
</div>
</div>
<div class="loader-div">
    <img src="img/loader.gif" class="loader-img" style="height: 120px; width: auto;">
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

<!-- Chart library -->
<script src="./plugins/chart.min.js"></script>
<!-- Icons library -->
<script src="plugins/feather.min.js"></script>
<!-- Custom scripts -->
<script src="js/script.js"></script>
<!-- Add Custom Js File -->
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>