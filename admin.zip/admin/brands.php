<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">All Brands</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">All Brands</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                                <a href="" class="btn btn-sm btn-warning">Add Brands</a>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search...">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Products</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td><img src="../images/posts/post-2.jpg" alt="" style="width: 90px; box-shadow: 0px 0px 3px 0px black; border-radius: 12px;"></td>
                                        <td>Man</td>
                                        <td>10</td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger">Pending</button>
                                        </td>
                                        <td>
                                            <a href="admin-details.php" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                                            <a href="admin-details.php" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>