<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Canceled Orders</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Canceled Orders</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Order Id">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Order ID|Time</th>
                                        <th>Customer</th>
                                        <th>Payment Via</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td>
                                            <p class="mb-4">asdkfjlskajflksad</p>
                                            <p>02-04-2019 03:34 বিকাল</p>
                                        </td>
                                        <td>maraz</td>
                                        <td>COD</td>
                                        <td>120.00</td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger">Pending</button>
                                        </td>
                                        <td>
                                            <a href="admin-details.php" class="btn btn-warning btn-sm m-1" title="View"><i class="fas fa-desktop"></i></a>
                                            <a href="admin-details.php" class="btn btn-success btn-sm m-1" title="Make Active"><i class="fa-solid fa-check"></i></a>
                                            <a href="admin-details.php" class="btn btn-danger btn-sm m-1" title="Delete"><i class="fa-solid fa-trash-arrow-up"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>