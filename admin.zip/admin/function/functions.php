<?php
/* 
    *   ******************************** 
    *   Other Function;
    *   *********************************
*/
// this function declare the page title name;
function MakeUniqueTitleNameLikeThePageName($filename)
{
    // Remove the file extension (.php) if it's present
    $filename = str_replace('.php', '', $filename);
    // Split the filename into words using hyphens or underscores as separators
    $words = preg_split('/[-_]/', $filename);
    // Capitalize the first letter of each word and join them with a space
    $displayName = ucwords(implode(' ', $words));
    return $displayName;
}

/* 
    *   ******************************** 
    *   Here Call Data From Database;
    *   *********************************
*/
//  Get All Admin user;
function getAdminUserDetails($status)
{
    global $connect;
    $data   =   [];
    if ($status == 'ALL') {
        $sql = "SELECT `id`, `name`, `email`, `phone`, `image`, `password`, `created_at`, `emailVerify`, `status` FROM `admin`";
    } elseif ($status == 0) {
        $sql = "SELECT `id`, `name`, `email`, `phone`, `image`, `password`, `created_at`, `emailVerify`, `status` FROM `admin` WHERE status = '0'";
    } elseif ($status == 1) {
        $sql = "SELECT `id`, `name`, `email`, `phone`, `image`, `password`, `created_at`, `emailVerify`, `status` FROM `admin` WHERE status = '1'";
    }
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get single admin user details
function getSingleAdminUserDetails($id)
{
    global $connect;
    $data   =   [];
    $id = base64_decode($id);
    $sql = "SELECT `id`, `name`, `role`, `email`, `phone`, `image`, `address`, `city`, `state`, `zip-postal`, `country`, `password`, `token`, `created_at`, `emailVerify`, `status` FROM `admin` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $mysqli_num_rows = mysqli_num_rows($rel);
    if ($mysqli_num_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get admin loign log;
function getAdminUserLoignLog($email)
{
    global $connect;
    $data   =   [];
    $email = base64_decode($email);
    if ($email == 'none') {
        $sql = "SELECT `id`, `type`, `email`, `date` FROM `adminlog` WHERE type = 'Login'";
    } else {
        $sql = "SELECT `id`, `type`, `email`, `date` FROM `adminlog` WHERE type = 'Login' AND email = '$email'";
    }
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get admin eamil log;
function getAdminUserEamilLog($email)
{
    global $connect;
    $data   =   [];
    $email = base64_decode($email);
    if ($email == 'none') {
        $sql = "SELECT `id`, `type`, `email`, `subject`, `text`, `date` FROM `adminlog` WHERE type = 'email'";
    } else {
        $sql = "SELECT `id`, `type`, `email`, `subject`, `text`, `date` FROM `adminlog` WHERE type = 'email' AND email = '$email'";
    }
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get admin eamil message details;
function getAdminUserEamilDetails($id)
{
    global $connect;
    $data   =   [];
    $id = base64_decode($id);
    $sql = "SELECT `id`, `type`, `email`, `subject`, `text`, `date` FROM `adminlog` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $mysqli_num_rows = mysqli_num_rows($rel);
    if ($mysqli_num_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// get product category
function getProductCategory()
{
    global $connect;
    $data   =   [];
    $sql = "SELECT `id`, `name`, `metaTitle`, `metaDescription`, `metaKeywords`, `image`, `is_top`, `is_special`, `created_at`, `created_by`, `status` FROM `categories`";
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get All category Name and id;
function getAllCategoryNameandId()
{
    global $connect;
    $data   =   [];
    $sql = "SELECT `id`, `name`, `status` FROM `categories` WHERE status = '0'";
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// This process is for Get Category Name;
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'getSubcateNameBYCate') {
    session_start();
    include '../../database/db.php';
    $category_id = $_POST['category_id'];
    $cId = base64_decode($category_id);
    $sql = "SELECT `id`, `category`, `name`, `status` FROM `subcategory` WHERE category = '$cId' AND status = '0'";
    $rel = mysqli_query($connect, $sql);
    if ($rel) {
        $data = [];
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
        // Generate options for the product select box
        $options = "<option value=''>Select Sub Category</option>";
        foreach ($data as $Value) {
            $id = $Value["id"];
            $id = base64_encode($id);
            $name = $Value["name"];
            $options .= "<option value='{$id}'>$name</option>";
        }
    }
    echo $options;
}
// get product sub category
function getAllProductSubCategory()
{
    global $connect;
    $data   =   [];
    $sql = "SELECT `id`, `category`, `name`, `metaTiitle`, `metaDes`, `metaKey`, `image`, `createdBy`, `createAt`, `status` FROM `subcategory`";
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// get product child Sub category
function getAllProductChildSubCategory()
{
    global $connect;
    $data   =   [];
    $sql = "SELECT `id`, `category`, `subcategory`, `name`, `metaTiitle`, `metaDes`, `metaKey`, `image`, `createdBy`, `createAt`, `status` FROM `subchildcategory`";
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        while ($row = mysqli_fetch_assoc($rel)) {
            array_push($data, $row);
        }
    }
    return $data;
}
// Get Category Name By sub cate id;
function getCategoryNameBySubCateId($id)
{
    global $connect;
    $id = base64_decode($id);
    $sql = "SELECT `name` FROM `categories` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($rel);
    $data = $row['name'];
    return $data;
}
// Get Sub Category Name By sub cate id;
function getSubCategoryNameByChildSubCateId($id)
{
    global $connect;
    $id = base64_decode($id);
    $sql = "SELECT `name` FROM `subcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($rel);
    $data = $row['name'];
    return $data;
}

/* 
    *   ******************************** 
    *   Here Add New Data;
    *   *********************************
*/
// This process is for add new admin
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'AddNewAdmin') {
    include '../../database/db.php';
    include('../../plugins/smtp/PHPMailerAutoload.php');
    include('../../database/commonFunction.php');
    $name = $_POST['DataName'];
    $email = $_POST['DataEmail'];
    $role = $_POST['DataRole'];
    $response;
    // check email is used or not;
    $sql = "SELECT * FROM `admin` WHERE email = '$email'";
    $rel = mysqli_query($connect, $sql);
    if (mysqli_num_rows($rel) > 0) {
        $response = 'emailAdded';
    } else {
        $date = date(" h:i:s d:m:y");
        $token = md5($date);
        $type = base64_encode('addNewAdmin');
        $UpdateSql = "INSERT INTO `admin`(`name`, `role`, `email`, `token`, `emailVerify`, `status`) VALUES 
        ('$name','$role','$email','$token','1','1')";
        $insertRel = mysqli_query($connect, $UpdateSql);
        if ($status != 0) {
            $User = "Moderator";
        } else {
            $User = "Admin";
        }
        $html = "
            <html>
                <center style='font-size: larger;'>
                    <h4>Welcome to our E-COM</h4>
                    <p style='margin-bottom: 30px;'>Please join as a $User In <b>E-COM</b>. Please click the link and and confirm you account.</p>
                    <a href='http://localhost/e-com/authorization.php?token={$token}&type={$type}' style='text-decoration: none; width: 10px; border: 1px solid red; padding: 10px; background: greenyellow; color: black; font-weight: bolder;'>Verify Your Account</a>
                </center>
            </html>
        ";
        $subject = "Please Confirm Your Account";
        $text = '<html>
            <center style="font-size: larger;">
                <h4>Welcome to our E-COM</h4>
                <p style="margin-bottom: 30px;">Please join as a $User In <b>E-COM</b>. Please click the link and and confirm you account.</p>
                <a href="http://localhost/e-com/authorization.php?token=' . $token . '&type=' . $type . '" style="text-decoration: none; width: 10px; border: 1px solid red; padding: 10px; background: greenyellow; color: black; font-weight: bolder;">Verify Your Account</a>
            </center>
        </html>
        ';
        $upSQL = "INSERT INTO `adminlog`(`type`, `email`, `subject`,`text`) VALUES ('email','$email','$subject','$text')";
        $upRel = mysqli_query($connect, $upSQL);
        smtp_mailer($email, $subject, $html);
        $response = "SuccessfullySend";
    }
    echo $response;
}
// This process is for add new Category
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'addNewCategory') {
    session_start();
    include '../../database/db.php';
    $cateImage      = $_FILES["image"];
    $cateName       = $_POST["cateName"];
    $metaTitle      = $_POST["metaTitle"];
    $metaDes        = $_POST["metaDes"];
    $metaKeywords   = $_POST["metaKeywords"];
    $response;
    // check the name is already add or not in database;
    $sql = "SELECT * FROM `categories` WHERE name = '$cateName'";
    $rel = mysqli_query($connect, $sql);
    if (mysqli_num_rows($rel) > 0) {
        $response = 'categoryNameIsAlreadyFounded';
    } else {
        $file    =  $_FILES['image']['name'];
        $imgPath =  $_FILES['image']['tmp_name'];
        $imgSize =  $_FILES['image']['size'];
        list($width, $height, $type, $attr) = getimagesize($imgPath);
        if ($width != 200 || $height != 150) {
            $response = 'CategoryImageSizeDoesNotMatch';
        } else {
            $allowed_file_types     =   ['png', 'jpg', 'jpeg'];
            $user_file_type_array   =   explode('.', $file);
            $user_file_type         =   end($user_file_type_array);
            if (!in_array($user_file_type, $allowed_file_types)) {
                $response = 'FileTypeDoesNotMatched';
            } elseif ($imgSize > 4000000) {
                $response = 'FileSouldBe500kb';
            } else {
                $destination = '../../images/categories/';
                $destination_file    =   $destination . $file;
                move_uploaded_file($imgPath, $destination_file);
                $email = base64_decode($_SESSION['AdminUserEmail']);
                $sql = "INSERT INTO `categories`(`name`, `metaTitle`, `metaDescription`, `metaKeywords`, `image`, `is_top`, `is_special`, `created_by`, `status`) VALUES ('$cateName','$metaTitle','$metaDes','$metaKeywords','$file','1','1','$email','0')";
                $rel = mysqli_query($connect, $sql);
                $response = 'successfullyUpload';
            }
        }
    }
    echo $response;
}
// This process is for add new Sub Category
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'addNewSubCategory') {
    session_start();
    include '../../database/db.php';
    $cateImage      = $_FILES["image"];
    $Categroy       = base64_decode($_POST["Categroy"]);
    $SubcateName    = $_POST["cateName"];
    $metaTitle      = $_POST["metaTitle"];
    $metaDes        = $_POST["metaDes"];
    $metaKeywords   = $_POST["metaKeywords"];
    $response;
    // check the name is already add or not in database;
    $sql = "SELECT * FROM `subcategory` WHERE name = '$SubcateName' AND category = '$Categroy'";
    $rel = mysqli_query($connect, $sql);
    if (mysqli_num_rows($rel) > 0) {
        $response = 'subcategoryNameIsAlreadyFounded';
    } else {
        $file    =  $_FILES['image']['name'];
        $imgPath =  $_FILES['image']['tmp_name'];
        $imgSize =  $_FILES['image']['size'];
        list($width, $height, $type, $attr) = getimagesize($imgPath);
        if ($width != 200 || $height != 150) {
            $response = 'subCategoryImageSizeDoesNotMatch';
        } else {
            $allowed_file_types     =   ['png', 'jpg', 'jpeg'];
            $user_file_type_array   =   explode('.', $file);
            $user_file_type         =   end($user_file_type_array);
            if (!in_array($user_file_type, $allowed_file_types)) {
                $response = 'FileTypeDoesNotMatched';
            } elseif ($imgSize > 4000000) {
                $response = 'FileSouldBe500kb';
            } else {
                $destination = '../../images/categories/sub-category/';
                $destination_file    =   $destination . $file;
                move_uploaded_file($imgPath, $destination_file);
                $email = base64_decode($_SESSION['AdminUserEmail']);
                $sql = "INSERT INTO `subcategory`(`category`, `name`, `metaTiitle`, `metaDes`, `metaKey`, `image`, `createdBy`, `status`) VALUES ('$Categroy', '$SubcateName','$metaTitle','$metaDes','$metaKeywords','$file','$email','0')";
                $rel = mysqli_query($connect, $sql);
                $response = 'successfullyUpload';
            }
        }
    }
    echo $response;
}
// This process is for add new Sub Child Category
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'addNewSubChildCategory') {
    session_start();
    include '../../database/db.php';
    $cateImage      = $_FILES["image"];
    $Categroy       = base64_decode($_POST["categroy"]);
    $SubCategroy    = base64_decode($_POST["SubCategroy"]);
    $cateName       = $_POST["cateName"];
    $metaTitle      = $_POST["metaTitle"];
    $metaDes        = $_POST["metaDes"];
    $metaKeywords   = $_POST["metaKeywords"];
    $response;
    // check the name is already add or not in database;
    $sql = "SELECT * FROM `subchildcategory` WHERE name = '$cateName' AND category = '$Categroy' AND subcategory = '$SubCategroy'";
    $rel = mysqli_query($connect, $sql);
    if (mysqli_num_rows($rel) > 0) {
        $response = 'subcategoryNameIsAlreadyFounded';
    } else {
        $file    =  $_FILES['image']['name'];
        $imgPath =  $_FILES['image']['tmp_name'];
        $imgSize =  $_FILES['image']['size'];
        list($width, $height, $type, $attr) = getimagesize($imgPath);
        if ($width != 200 || $height != 150) {
            $response = 'subCategoryImageSizeDoesNotMatch';
        } else {
            $allowed_file_types     =   ['png', 'jpg', 'jpeg'];
            $user_file_type_array   =   explode('.', $file);
            $user_file_type         =   end($user_file_type_array);
            if (!in_array($user_file_type, $allowed_file_types)) {
                $response = 'FileTypeDoesNotMatched';
            } elseif ($imgSize > 4000000) {
                $response = 'FileSouldBe500kb';
            } else {
                $destination = '../../images/categories/sub-category/child-category/';
                $destination_file    =   $destination . $file;
                move_uploaded_file($imgPath, $destination_file);
                $email = base64_decode($_SESSION['AdminUserEmail']);
                $sql = "INSERT INTO `subchildcategory`(`category`, `subcategory`, `name`, `metaTiitle`, `metaDes`, `metaKey`, `image`, `createdBy`,`status`) VALUES ('$Categroy', '$SubCategroy','$cateName','$metaTitle','$metaDes','$metaKeywords','$file','$email','0')";
                $rel = mysqli_query($connect, $sql);
                $response = 'successfullyUpload';
            }
        }
    }
    echo $response;
}

/* 
    *   ******************************** 
    *   Here Update Data;
    *   *********************************
*/
// Update Admin Information;
if (isset($_POST['UpdateAdminInformation'])) {
    // stor data in variable;
    $name       = input_sanitize_process($_POST['fullName']);
    $address    = input_sanitize_process($_POST['address']);
    $city       = input_sanitize_process($_POST['city']);
    $state      = input_sanitize_process($_POST['state']);
    $zipPostal  = input_sanitize_process($_POST['zipPostal']);
    $country    = input_sanitize_process($_POST['country']);
    $role       = input_sanitize_process($_POST['role']);
    $status     = input_sanitize_process($_POST['status']);
    $id         = input_sanitize_process($_POST['id']);
    if (empty($name)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "First Name Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($address)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Address Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($city)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "City Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($state)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "State Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($zipPostal)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Zip Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($country)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Country Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($role)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Role Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    } elseif (empty($status)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Status Is Required!"];
        header("location: admin-details.php?id=$id");
        exit;
    }
    if ($status == 'active') {
        $status = 0;
    } else {
        $status = 1;
    }
    if ($role == 'admin') {
        $role = 0;
    } else {
        $role = 1;
    }
    $id = base64_decode($id);
    $upSql = "UPDATE `admin` SET `name`='$name',`role`='$role',`address`='$address',`city`='$city',`state`='$state',`zip-postal`='$zipPostal',`country`='$country',`status`='$status;' WHERE id = '$id'";
    $upRel = mysqli_query($connect, $upSql);
    $_SESSION['AlertMess'] = ["type" => "success", "mess" => "Successfully Updated"];
    $id = base64_encode($id);
    header("location: admin-details.php?id=$id");
    exit;
}
// Update Category
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'UpdateCategory') {
    session_start();
    include '../../database/db.php';
    $id         = $_POST["id"];
    $cateogry   = $_POST["cateogry"];
    $metaTitle  = $_POST["metaTitle"];
    $metaDes    = $_POST["metaDes"];
    $metaKey    = $_POST["metaKey"];
    $response;
    $email = base64_decode($_SESSION['AdminUserEmail']);
    $date = date('l jS \o\f F Y h:i:s A');
    // First Update log;
    $logSql = "INSERT INTO `adminlog`(`type`, `email`, `text`, `date`) VALUES ('UpdateCategory','$email','Update Category','$date')";
    $logRel = mysqli_query($connect, $logSql);
    // Update category
    $sql = "UPDATE `categories` SET `name`='$cateogry',`metaTitle`='$metaTitle',`metaDescription`='$metaDes',`metaKeywords`='$metaKey' WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    if($rel && $logRel){
        $response = 'success';
    }else{
        $response = 'error';
    }
    echo $response;
}
/* 
    *   ******************************** 
    *   Here Status Control;
    *   *********************************
*/
// This process is for admin manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'MangeAdminStatus') {
    include '../../database/db.php';
    $id = $_POST['adminUserId'];
    $response;
    // get user details;
    $sql = "SELECT `status` FROM `admin` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $data = mysqli_fetch_assoc($rel);
    $status = $data['status'];
    if ($status != 0) {
        $sql = "UPDATE `admin` SET `status`='0' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'active';
    } else {
        $sql = "UPDATE `admin` SET `status`='1' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'unactive';
    }
    echo $response;
}
// This process is for Product Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'MangeProductCategoryStatus') {
    include '../../database/db.php';
    $id = $_POST['productId'];
    $response;
    // get user details;
    $sql = "SELECT `status` FROM `categories` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $data = mysqli_fetch_assoc($rel);
    $status = $data['status'];
    if ($status != 0) {
        $sql = "UPDATE `categories` SET `status`='0' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'active';
    } else {
        $sql = "UPDATE `categories` SET `status`='1' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'unactive';
    }
    echo $response;
}
// This process is for Product Sub Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'MangeProductSubCategoryStatus') {
    include '../../database/db.php';
    $id = $_POST['productId'];
    $response;
    // get user details;
    $sql = "SELECT `status` FROM `subcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $data = mysqli_fetch_assoc($rel);
    $status = $data['status'];
    if ($status != 0) {
        $sql = "UPDATE `subcategory` SET `status`='0' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'active';
    } else {
        $sql = "UPDATE `subcategory` SET `status`='1' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'unactive';
    }
    echo $response;
}
// This process is for Product Sub Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'MangeProductSubChildCategoryStatus') {
    include '../../database/db.php';
    $id = $_POST['productId'];
    $response;
    // get user details;
    $sql = "SELECT `status` FROM `subchildcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    $data = mysqli_fetch_assoc($rel);
    $status = $data['status'];
    if ($status != 0) {
        $sql = "UPDATE `subchildcategory` SET `status`='0' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'active';
    } else {
        $sql = "UPDATE `subchildcategory` SET `status`='1' WHERE id = '$id'";
        $rel = mysqli_query($connect, $sql);
        $response = 'unactive';
    }
    echo $response;
}
/* 
    *   ******************************** 
    *   Here Delete Control;
    *   *********************************
*/
// This process is for Product Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'DeleteProductCategory') {
    include '../../database/db.php';
    session_start();
    $id = $_POST['productId'];
    $isError = false;
    $response;
    // Find Sub Category Name;
    $findNameSql = "SELECT * FROM `categories` WHERE id = '$id'";
    $rel = mysqli_query($connect, $findNameSql);
    $data = mysqli_fetch_assoc($rel);
    $CateName = $data["name"];
    // Update Database;
    $email = base64_decode($_SESSION['AdminUserEmail']);
    $text = "Delete the {$CateName} Category";
    $date = date('l jS \o\f F Y h:i:s A');
    $Upsql = "INSERT INTO `adminlog`(`type`, `email`, `text`, `date`) VALUES ('CategoryDelete','$email','$text', '$date')";
    $UpRel = mysqli_query($connect, $Upsql);
    // get user details;
    $sql = "DELETE FROM `categories` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    if ($rel) {
        $response = 'success';
    } else {
        $response = 'error';
    }
    // something went wrong
    echo $response;
}
// This process is for Product Sub Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'DeleteProductSubCategory') {
    include '../../database/db.php';
    session_start();
    $id = $_POST['productId'];
    $isError = false;
    $response;
    // Find Sub Category Name;
    $findNameSql = "SELECT * FROM `subcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $findNameSql);
    $data = mysqli_fetch_assoc($rel);
    $subCateName = $data["name"];
    // Update Database;
    $email = base64_decode($_SESSION['AdminUserEmail']);
    $text = "Delete the {$subCateName} Sub Category";
    $date = date('l jS \o\f F Y h:i:s A');
    $Upsql = "INSERT INTO `adminlog`(`type`, `email`, `text`, `date`) VALUES ('CategoryDelete','$email','$text', '$date')";
    $UpRel = mysqli_query($connect, $Upsql);
    // get user details;
    $sql = "DELETE FROM `subcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    if ($rel) {
        $response = 'success';
    } else {
        $response = 'error';
    }
    // something went wrong
    echo $response;
}
// This process is for Product Sub child Cateogry manage status
if (isset($_GET['operation_type']) && $_GET['operation_type'] === 'DeleteProductSubChildCategory') {
    include '../../database/db.php';
    session_start();
    $id = $_POST['productId'];
    $isError = false;
    $response;
    // Find Sub Category Name;
    $findNameSql = "SELECT * FROM `subchildcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $findNameSql);
    $data = mysqli_fetch_assoc($rel);
    $subCateName = $data["name"];
    // Update Database;
    $email = base64_decode($_SESSION['AdminUserEmail']);
    $text = "Delete the {$subCateName} Sub child Category";
    $date = date('l jS \o\f F Y h:i:s A');
    $Upsql = "INSERT INTO `adminlog`(`type`, `email`, `text`, `date`) VALUES ('CategoryDelete','$email','$text', '$date')";
    $UpRel = mysqli_query($connect, $Upsql);
    // get user details;
    $sql = "DELETE FROM `subchildcategory` WHERE id = '$id'";
    $rel = mysqli_query($connect, $sql);
    if ($rel) {
        $response = 'success';
    } else {
        $response = 'error';
    }
    // something went wrong
    echo $response;
}
