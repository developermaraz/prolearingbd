<?php
date_default_timezone_set('Asia/Dhaka');
// date("d-m-y");
// echo date("h:i:s am/pm");
echo date('l jS \o\f F Y h:i:s A');
