<?php
if (isset($_POST['loginBtn'])) {
    // * Stor data in variable
    $email      = input_sanitize_process($_POST['email']);
    $password   = input_sanitize_process($_POST['password']);
    // check email is emtpy or not;
    if (empty($email)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Email Is Required!"];
        header("Location: login");
        exit;
    } else {
        $_SESSION['provitedEmailAddress'] = $email;
    }
    // Check password is empty or not;
    if (empty($password)) {
        $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Password Is Required!"];
        header("Location: login");
        exit;
    } else {
        // encode password;
        $password = $password . '34@#@#@%@#$#$%^$%^&$%^&$%$#@$#$^#$%^@#$#$^#$!@$!';
        $password = md5($password);
        $password = base64_encode($password);
        $password = $password . '34@#@#@%@#$#$%^$%^&$%^&$%$#@$#$^#$%^@#$#$^#$!@$!' . $password;
        $password = md5($password);
        $password = sha1($password);
        $password = md5($password);
        $pass = sha1($password);
    }
    // check email and password match or not;
    $sql = "SELECT `email`, `password` FROM `admin` WHERE email = '$email' AND password = '$pass'";
    $rel = mysqli_query($connect, $sql);
    $num_of_rows = mysqli_num_rows($rel);

    // echo mysqli_num_rows($rel);
    if ($num_of_rows > 0) {
        $dataSql    = "SELECT `role`,`name`, `email`, `emailVerify`, `status` FROM `admin` WHERE email = '$email' AND password = '$pass'";
        $dataRel    = mysqli_query($connect, $dataSql);
        $data       = mysqli_fetch_assoc($dataRel);
        $emailVerify    = $data['emailVerify'];
        // check email status;
        if($emailVerify != 0){
            $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Email Unverified"];
            header("Location: login");
            exit;
        }else{
            $status = $data['status'];
            if($status != 0){
                $_SESSION['AlertMess'] = ["type" => "error", "mess" => "You are unactive. Please contant with admin."];
                header("Location: login");
                exit;
            }else{
                $_SESSION['AdminUserName'] = base64_encode($data['name']);
                $_SESSION['AdminUserEmail'] = base64_encode($data['email']);
                $_SESSION['AdminUserRole'] = base64_encode($data['role']);
                $_SESSION['successfullyLoginStatus'] = 0;
                $adminLogSql = "INSERT INTO `adminlog`(`type`, `email`) VALUES ('Login','$email')";
                $adminLogRel = mysqli_query($connect, $adminLogSql);
                if($_POST['PassRememberMe'] == 'on'){
                    // set cookie
                    $cookEmail = encryptCookieData($email);
                    setcookie("email", $cookEmail, [
                        "expires" => time() + 259200,
                        "path" => "/",
                        "domain" => "localhost",
                        "secure" => true,
                        "httponly" => true,
                        "samesite" => "Lax" 
                    ]);
                    $cookPass = encryptCookieData($_POST["password"]);
                    setcookie("pass", $cookPass, [
                        "expires" => time() + 259200,
                        "path" => "/",
                        "domain" => "localhost",
                        "secure" => true,
                        "httponly" => true,
                        "samesite" => "Lax" 
                    ]);
                }
                header("Location: dashboard");
                exit;
            }
        }
    } else {
        // count attempt
        if (isset($_SESSION['count'])) {
            $_SESSION['count']++;
        } else {
            $_SESSION['count'] = 1;
        }
        $attemptCount = $_SESSION['count'];
        if ($attemptCount > 3) {
            $ip = gethostbyname('localhost');
            // Report to 403
            $sql = "INSERT INTO `blockip`(`type`, `ip`, `reson`, `status`) VALUES ('0','$ip','3 Times Rong Password','0')";
            $rel = mysqli_query($connect, $sql);
            header("Location: ../403");
            exit;
        } else {
            $_SESSION['AlertMess'] = ["type" => "error", "mess" => "Email & Password does not match"];
            header("Location: login");
            exit;
        }
    }
}
