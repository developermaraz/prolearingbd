<?php
// start session;
session_start();
// check login or not;
if(isset($_SESSION['successfullyLoginStatus']) && $_SESSION['successfullyLoginStatus'] ==0){
    $_SESSION['AlertMess'] = ["type" => "warning", "mess" => "Alreay Login"];
    header("Location: dashboard");
    exit;
}
// Connect Database;
require('../database/db.php');
// check common security function;
require('../database/commonFunction.php');
// connect login function;
require('function/login-function.php');
// check common security function;
checkTheUserIsBlockOrNot();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - E-COM</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="img/svg/logo.svg" type="image/x-icon">
    <!-- Custom styles -->
    <link rel="stylesheet" href="css/style.min.css">
    <script src="../js/jquery-3.7.1.min.js"></script>
    <script src="../js/sweetalert2.net_npm_sweetalert2@11"></script>
</head>

<body>
    <div class="layer"></div>
    <main class="page-center">
        <article class="sign-up">
            <h1 class="sign-up__title">Welcome back!</h1>
            <p class="sign-up__subtitle">Sign in to your account to continue</p>
            <form class="sign-up-form form" action="" method="POST">
                <label class="form-label-wrapper">
                    <p class="form-label">Email</p>
                    <input class="form-input" type="email" placeholder="Enter your email" name="email" value="<?php if(isset($_SESSION['provitedEmailAddress']) && !empty($_SESSION['provitedEmailAddress'])){ echo $_SESSION['provitedEmailAddress']; unset($_SESSION['provitedEmailAddress']); } if(isset($_COOKIE["email"]) && !empty($_COOKIE["email"])){ echo decryptCookieData($_COOKIE["email"]); } ?>">
                </label>
                <label class="form-label-wrapper">
                    <p class="form-label">Password</p>
                    <input class="form-input" type="password" name="password" placeholder="Enter your password" value="<?php if(isset($_COOKIE["pass"]) && !empty($_COOKIE["pass"])){ echo decryptCookieData($_COOKIE["pass"]); } ?>">
                </label>
                <a class="link-info forget-link" href="##">Forgot your password?</a>
                <label class="form-checkbox-wrapper">
                    <input class="form-checkbox" name="PassRememberMe" type="checkbox">
                    <span class="form-checkbox-label">Remember me next time</span>
                </label>
                <button type="submit" name="loginBtn" class="form-btn primary-default-btn transparent-btn">Login</button>
            </form>
        </article>
    </main>

    <audio id="notificationSound">
        <source src="../sound/notification.mp3" type="audio/mp3">
    </audio>

<?php
if(isset($_SESSION['AlertMess']) && !empty($_SESSION['AlertMess'])){
    ?>
    <script>
        document.getElementById('notificationSound').play();
    </script>
    <?php
    $type = $_SESSION['AlertMess']["type"];
    $mess = $_SESSION['AlertMess']["mess"];
    AlertMessage($type, $mess);
    unset($_SESSION['AlertMess']);
}
?>



    <!-- Chart library -->
    <script src="./plugins/chart.min.js"></script>
    <!-- Icons library -->
    <script src="plugins/feather.min.js"></script>
    <!-- Custom scripts -->
    <script src="js/script.js"></script>
</body>

</html>