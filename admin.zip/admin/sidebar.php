<style>
    
.category, .edit, .product{
  background-image: url(img/svg/Bulk/Bag\ 3.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .Promotions{
  background-image: url(img/svg/Bulk/Bookmark.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .Payments{
  background-image: url(img/svg/Bulk/Wallet.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .MangeSection{
  background-image: url(img/svg/Bulk/Show.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .PaymentsGetWays{
  background-image: url(img/svg/Bulk/Swap.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .SystemInformation{
  background-image: url(img/svg/Bulk/Info\ Square.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .CreateTicket{
  background-image: url(img/svg/Bulk/Send.svg);
  width: 24px;
  height: 24px;
}

.category, .edit, .Notification{
  background-image: url(img/svg/Bulk/Notification-gray.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .Order{
  background-image: url(img/svg/Bulk/Buy.svg);
  width: 24px;
  height: 24px;
}
.category, .edit, .GlobalSeo{
  background-image: url(img/svg/Bulk/Activity.svg);
  width: 24px;
  height: 24px;
}
</style>
<aside class="sidebar">
    <div class="sidebar-start">
        <div class="sidebar-head">
            <a href="dashboard" class="logo-wrapper" title="Home">
                <span class="sr-only">Home</span>
                <span class="icon logo" aria-hidden="true"></span>
                <div class="logo-text">
                    <span class="logo-title">E-Com</span>
                </div>

            </a>
            <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                <span class="sr-only">Toggle menu</span>
                <span class="icon menu-toggle" aria-hidden="true"></span>
            </button>
        </div>
        <div class="sidebar-body">
            <ul class="sidebar-body-menu">
                <li>
                    <a class="<?php if($page == 'dashboard.php'){ echo 'active'; }?>" href="dashboard"><span class="icon home" title="Dashboard" aria-hidden="true"></span>Dashboard</a>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;">Users</li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'admin-email-log.php' || $page == 'admin-login-log.php' || $page == 'all-admin.php' || $page == 'active-admin.php' || $page == 'pending-admin.php'){ echo 'active'; }?>" href="##">
                        <span class="icon user-3" title="Admin Control" aria-hidden="true"></span>Admin
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="all-admin" class="<?php if($page == 'all-admin.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>All Admin</a>
                        </li>
                        <li>
                            <a href="active-admin" class="<?php if($page == 'active-admin.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Active Admin</a>
                        </li>
                        <li>
                            <a href="pending-admin" class="<?php if($page == 'pending-admin.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Pending Admin</a>
                        </li>
                        <li>
                            <a href="admin-login-log" class="<?php if($page == 'admin-login-log.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Login Log</a>
                        </li>
                        <li>
                            <a href="admin-email-log" class="<?php if($page == 'admin-email-log.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Email Log</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'all-customer.php' || $page == 'active-customer.php' || $page == 'banned-customer.php' || $page == 'customer-email-unverified.php' || $page == 'customer-sms-unverified.php' || $page == 'customer-send-email.php'){ echo 'active'; }?>" href="#">
                        <span class="icon user-3" title="Customer Control" aria-hidden="true"></span>Customers
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="all-customer" class="<?php if($page == 'all-customer.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>All Customer</a>
                        </li>
                        <li>
                            <a href="active-customer" class="<?php if($page == 'active-customer.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Active Customers</a>
                        </li>
                        <li>
                            <a href="banned-customer" class="<?php if($page == 'banned-customer.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Banned Customers</a>
                        </li>
                        <li>
                            <a href="customer-email-unverified" class="<?php if($page == 'customer-email-unverified.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Email Unverified</a>
                        </li>
                        <li>
                            <a href="customer-sms-unverified" class="<?php if($page == 'customer-sms-unverified.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>SMS Unverified</a>
                        </li>
                        <li>
                            <a href="customer-send-email" class="<?php if($page == 'customer-send-email.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Send Email</a>
                        </li>
                    </ul>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> Shop</li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'product-categories.php' || $page == 'brands.php' || $page == 'products.php' || $page == 'trashed-products.php' || $page == 'product-reviews.php'){ echo 'active'; }?>" href="#">
                        <span class="icon product" title="Product" aria-hidden="true"></span>Product
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="product-categories" class="<?php if($page == 'product-categories.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Categories</a>
                        </li>
                        <li>
                            <a href="brands" class="<?php if($page == 'brands.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Brands</a>
                        </li>
                        <li>
                            <a href="products" class="<?php if($page == 'products.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Products</a>
                        </li>
                        <li>
                            <a href="trashed-products" class="<?php if($page == 'trashed-products.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Trashed Products</a>
                        </li>
                        <li>
                            <a href="product-reviews" class="<?php if($page == 'product-reviews.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Product Reviews</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'all-orders.php' || $page == 'pending-orders.php' || $page == 'delivered-orders.php' || $page == 'canceled-orders.php' || $page == 'cod-orders.php' || $page == 'sales-log.php'){ echo 'active'; }?>" href="#">
                        <span class="icon Order" title="Order" aria-hidden="true"></span>Orders
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="all-orders" class="<?php if($page == 'all-orders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> All Orders</a>
                        </li>
                        <li>
                            <a href="pending-orders" class="<?php if($page == 'pending-orders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Pending Orders</a>
                        </li>
                        <li>
                            <a href="delivered-orders" class="<?php if($page == 'delivered-orders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Delivered Orders</a>
                        </li>
                        <li>
                            <a href="canceled-orders" class="<?php if($page == 'canceled-orders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Canceled Orders</a>
                        </li>
                        <li>
                            <a href="cod-orders" class="<?php if($page == 'cod-orders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> COD Orders</a>
                        </li>
                        <li>
                            <a href="sales-log" class="<?php if($page == 'sales-log.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Sales Log</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'coupons.php' || $page == 'offers.php' || $page == 'subscribers.php'){ echo 'active'; }?>" href="#">
                        <span class="icon Promotions" title="Promotion" aria-hidden="true"></span>Promotion
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="coupons" class="<?php if($page == 'coupons.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Coupons</a>
                        </li>
                        <li>
                            <a href="offers" class="<?php if($page == 'offers.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>  Offers</a>
                        </li>
                        <li>
                            <a href="subscribers" class="<?php if($page == 'subscribers.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Subscribers</a>
                        </li>
                    </ul>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> PAYMENTS</li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'all-payments.php' || $page == 'pending-payments.php' || $page == 'approved-payments.php' || $page == 'successful-payments.php' || $page == 'rejected-payments.php'){ echo 'active'; }?>" href="#">
                        <span class="icon Payments" title="Payments" aria-hidden="true"></span>Payments
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="all-payments" class="<?php if($page == 'all-payments.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> All Payments</a>
                        </li>
                        <li>
                            <a href="pending-payments" class="<?php if($page == 'pending-payments.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Pending Payments</a>
                        </li>
                        <li>
                            <a href="approved-payments" class="<?php if($page == 'approved-payments.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>  Approved Payments</a>
                        </li>
                        <li>
                            <a href="successful-payments" class="<?php if($page == 'successful-payments.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Success Payments</a>
                        </li>
                        <li>
                            <a href="rejected-payments" class="<?php if($page == 'rejected-payments.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Rejected Payments</a>
                        </li>
                    </ul>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> Manage Front</li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'authorize-email.php' || $page == 'promotional-banner.php' || $page == 'authorize-sms.php' || $page == 'banner-sliders.php' || $page == 'code-verify.php' || $page == 'manage-contact-page.php' || $page == 'manage-footer.php' || $page == 'manage-forgot-password.php' || $page == 'manage-login-page.php' || $page == 'manage-pages.php' || $page == 'manage-register.php' || $page == 'manage-reset-password.php' || $page == 'manage-social-media.php' || $page == 'manage-subscribe-section.php'){ echo 'active'; }?>" href="#">
                        <span class="icon MangeSection" title="Mange Section" aria-hidden="true"></span>Manage Section
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="authorize-email" class="<?php if($page == 'authorize-email.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Authorize Email</a>
                        </li>
                        <li>
                            <a href="authorize-sms" class="<?php if($page == 'authorize-sms.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Authorize SMS</a>
                        </li>
                        <li>
                            <a href="promotional-banner" class="<?php if($page == 'promotional-banner.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Promotional Banner</a>
                        </li>
                        <li>
                            <a href="banner-sliders" class="<?php if($page == 'banner-sliders.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Banner Sliders</a>
                        </li>
                        <li>
                            <a href="code-verify" class="<?php if($page == 'code-verify.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Code Verify</a>
                        </li>
                        <li>
                            <a href="manage-contact-page" class="<?php if($page == 'manage-contact-page.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Contact Page</a>
                        </li>
                        <li>
                            <a href="manage-footer" class="<?php if($page == 'manage-footer.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Footer</a>
                        </li>
                        <li>
                            <a href="manage-forgot-password" class="<?php if($page == 'manage-forgot-password.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Forgot Password</a>
                        </li>
                        <li>
                            <a href="manage-login-page" class="<?php if($page == 'manage-login-page.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Login Page</a>
                        </li>
                        <li>
                            <a href="manage-pages" class="<?php if($page == 'manage-pages.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Pages</a>
                        </li>
                        <li>
                            <a href="manage-register" class="<?php if($page == 'manage-register.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Register Page</a>
                        </li>
                        <li>
                            <a href="manage-reset-password" class="<?php if($page == 'manage-reset-password.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Reset Password</a>
                        </li>
                        <li>
                            <a href="manage-social-media" class="<?php if($page == 'manage-social-media.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Social Media</a>
                        </li>
                        <li>
                            <a href="manage-subscribe-section" class="<?php if($page == 'manage-subscribe-section.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i> Subscribe Section</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="<?php if($page == 'global-seo.php'){ echo 'active'; }?>" href="global-seo"><span class="icon GlobalSeo" title="Global SEO" aria-hidden="true"></span>Global SEO</a>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> System Settings</li>
                <li>
                    <a class="show-cat-btn <?php if($page == 'automatic-gateway.php' || $page == 'manual-gateway.php' || $page == 'general-settings.php'){ echo 'active'; }?>" href="#">
                        <span class="icon PaymentsGetWays" title="Payment Gateway" aria-hidden="true"></span>Payment Geteways
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="automatic-gateway" class="<?php if($page == 'automatic-gateway.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Automatic Gateway</a>
                        </li>
                        <li>
                            <a href="manual-gateway" class="<?php if($page == 'manual-gateway.php'){ echo 'active'; }?>"><i class="fas fa-square" style="padding-right: 10px;"></i>Manual Gateway</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="<?php if($page == 'general-settings.php'){ echo 'active'; }?>" href="general-settings"><span class="icon setting" title="General Settings" aria-hidden="true"></span>General Settings</a>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> Notification Section</li>
                <li>
                    <a class="<?php if($page == 'notification.php'){ echo 'active'; }?>" href="notification"><span class="icon Notification" title="Notification" aria-hidden="true"></span>Notification</a>
                </li>
                <li style="color: black; font-weight: 800; padding: 5px; background: white; border-radius: 5px; padding-left: 20px;"> Others</li>
                <li>
                    <a class="<?php if($page == 'system-information.php'){ echo 'active'; }?>" href="system-information"><span class="icon SystemInformation" title="System Information" aria-hidden="true"></span> System Information</a>
                </li>
                <li>
                    <a class="<?php if($page == 'ticket.php'){ echo 'active'; }?>" href="ticket"><span class="icon CreateTicket" title="Create Ticket" aria-hidden="true"></span> Create Ticket</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="sidebar-footer">
        <a href="##" class="sidebar-user">
            <span class="sidebar-user-img">
                <picture>
                    <source srcset="./img/avatar/avatar-illustrated-01.webp" type="image/webp"><img src="./img/avatar/avatar-illustrated-01.png" alt="User name">
                </picture>
            </span>
            <div class="sidebar-user-info">
                <span class="sidebar-user__title">Nafisa Sh.</span>
                <span class="sidebar-user__subtitle">Support manager</span>
            </div>
        </a>
    </div>
</aside>