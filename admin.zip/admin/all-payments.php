<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">All Payments</h2>
        <div class="row stat-cards mb-20">
            <div class="col-md-6 col-xl-4">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon bg-success">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num">৳ 1478 286</p>
                        <p class="stat-cards-info__title">Successful Payment</p>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-xl-4">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon bg-warning">
                        <i class="fa-solid fa-circle-pause"></i>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num">৳ 1478 286</p>
                        <p class="stat-cards-info__title">Pending Payment</p>
                    </div>
                </article>
            </div>
            <div class="col-md-6 col-xl-4">
                <article class="stat-cards-item">
                    <div class="stat-cards-icon bg-danger">
                        <i class="fa-solid fa-ban"></i>
                    </div>
                    <div class="stat-cards-info">
                        <p class="stat-cards-info__num">৳ 1478 286</p>
                        <p class="stat-cards-info__title">Rejected Payment</p>
                    </div>
                </article>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">All Payments</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Trx Number/Username">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Gateway|Txt</th>
                                        <th>Initiated</th>
                                        <th>User</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td>
                                            <p><b>Bkash</b></p>
                                            <p class="mt-2">3GJP7TW6KOTJ</p>
                                        </td>
                                        <td>
                                            <p>2023-05-01 07:24 বিকাল</p>
                                            <p class="mt-2">5 মাস আগে</p>
                                        </td>
                                        <td>Abdul Motin</td>
                                        <td>
                                            <p>৳7,650.00 + <span class="text-danger" title="Charge">0.00</span></p>
                                            <p class="mt-2">7,650.00 BDT</p>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger">Pending</button>
                                            <p class="mt-2">5 মাস আগে</p>
                                        </td>
                                        <td>
                                            <a href="" class="btn btn-sm btn-warning"><i class="fas fa-desktop"></i></a>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>