<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 30px;">Notifications</h2>
        <div class="row" style="box-shadow: 0px 0px 11px 4px wheat; border-radius: 12px;">
            <div class="col-md-12 border-dark p-3">
                <div class="row">
                    <div class="col-md-1">
                        <div style="background: red; color: white; width: 50px; height: 50px; text-align: center; vertical-align: middle; border-radius: 78px;">
                            <i class="fas fa-bell" style="font-size: 28px; text-align: center; vertical-align: middle; padding-top: 10px;"></i>
                        </div>
                    </div>
                    <div class="col-md-11">
                        <h5 class="main-title"><b>New Member Reasdfsad</b></h5>
                        <p class="main-title mt-2"> <i class="fas fa-clock text-danger"></i> 5 Month Ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5" style="box-shadow: 0px 0px 11px 4px wheat; border-radius: 12px;">
            <div class="col-md-12 border-dark p-3">
                <div class="row">
                    <div class="col-md-1">
                        <div style="background: red; color: white; width: 50px; height: 50px; text-align: center; vertical-align: middle; border-radius: 78px;">
                            <i class="fas fa-bell" style="font-size: 28px; text-align: center; vertical-align: middle; padding-top: 10px;"></i>
                        </div>
                    </div>
                    <div class="col-md-11">
                        <h5 class="main-title"><b>New Member Reasdfsad</b></h5>
                        <p class="main-title mt-2"> <i class="fas fa-clock text-danger"></i> 5 Month Ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5" style="box-shadow: 0px 0px 11px 4px wheat; border-radius: 12px;">
            <div class="col-md-12 border-dark p-3">
                <div class="row">
                    <div class="col-md-1">
                        <div style="background: red; color: white; width: 50px; height: 50px; text-align: center; vertical-align: middle; border-radius: 78px;">
                            <i class="fas fa-bell" style="font-size: 28px; text-align: center; vertical-align: middle; padding-top: 10px;"></i>
                        </div>
                    </div>
                    <div class="col-md-11">
                        <h5 class="main-title"><b>New Member Reasdfsad</b></h5>
                        <p class="main-title mt-2"> <i class="fas fa-clock text-danger"></i> 5 Month Ago</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>