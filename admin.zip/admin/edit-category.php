<?php
if (!isset($_GET['id'])) {
    header("Location: ../403");
} elseif (empty($_GET['id'])) {
    header("Location: ../403");
} else {
    $id = base64_decode($_GET["id"]);
}
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="main-title" style="padding-bottom: 10px;">Edit Categories</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="product-categories" class="btn btn-warning btn-sm"><i class="fa-solid fa-backward"></i> Back</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Edit Categories</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <?php
                        $sql = "SELECT `id`, `name`, `metaTitle`, `metaDescription`, `metaKeywords`, `image`, `is_top`, `is_special`, `created_at`, `created_by`, `status` FROM `categories` WHERE id = '$id'";
                        $rel = mysqli_query($connect, $sql);
                        $data = mysqli_fetch_assoc($rel);
                        ?>
                        <form>
                            <div class="row">
                                <div class="col-md-12 text-center align-middle">
                                    <div style="width:200px; height:150px; border:2px solid #ff5e00; text-align: center;">
                                        <img style="width: 200px; height:150px;" src="../images/categories/<?php echo $data['image']; ?>" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <h4 class="main-title">Category Name</h4>
                                    <input type="text" id="cateName" name="cateName" placeholder="Category Name" class="form-control mt-2 border-warning" value="<?php echo $data['name']; ?>">
                                </div>
                                <div class="col-md-6 mt-3">
                                    <h4 class="main-title">Meta Title</h4>
                                    <input type="text" id="metaTitle" name="metaTitle" placeholder="Meta Title" class="form-control mt-2 border-warning" value="<?php echo $data['metaTitle']; ?>">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <h4 class="main-title">Meta Description</h4>
                                    <textarea name="metaDes" id="metaDes" class="form-control border-warning mt-2" rows="5"><?php echo $data['metaDescription']; ?></textarea>
                                </div>
                                <div class="col-md-12 mt-3">
                                    <h4 class="main-title">Meta Keywords</h4>
                                    <input type="text" id="metaKeywords" name="metaKeywords" placeholder="Meta Keywords" class="form-control mt-2 border-warning" value="<?php echo $data['metaKeywords']; ?>">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <button type="button" class="btn btn-sm btn-warning w-100" onclick="UpdateCategory(<?php echo $id; ?>)">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    function UpdateCategory(id) {
        event.preventDefault();
        $(".loader-div").show();
        var cateName = document.getElementById("cateName").value;
        var metaTitle = document.getElementById("metaTitle").value;
        var metaDes = document.getElementById("metaDes").value;
        var metaKeywords = document.getElementById("metaKeywords").value;
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })
        // check image;
        if (cateName == '') {
            $(".loader-div").hide();
            document.getElementById("notificationSound").play();
            Toast.fire({
                icon: 'error',
                title: 'Category Name Is Required!'
            });
        } else if (metaTitle == '') {
            $(".loader-div").hide();
            document.getElementById("notificationSound").play();
            Toast.fire({
                icon: 'error',
                title: 'Meta Title Is Required!'
            });
        } else if (metaDes == '') {
            $(".loader-div").hide();
            document.getElementById("notificationSound").play();
            Toast.fire({
                icon: 'error',
                title: 'Meta Description Is Required!'
            });
        } else if (metaKeywords == '') {
            $(".loader-div").hide();
            document.getElementById("notificationSound").play();
            Toast.fire({
                icon: 'error',
                title: 'Meta Keywords Is Required!'
            });
        } else {
            $.ajax({
                url: "function/functions.php?operation_type=UpdateCategory",
                type: "POST",
                dataType: 'html',
                data: {
                    id : id,
                    cateogry: cateName,
                    metaTitle: metaTitle,
                    metaDes: metaDes,
                    metaKey: metaKeywords,
                },
                success: function(response) {
                    if (response === 'success') {
                        $(".loader-div").hide();
                        Toast.fire({
                            icon: 'success',
                            title: 'Successfully Updated'
                        });
                        document.getElementById('notificationSound').play();
                    } else {
                        $(".loader-div").hide();
                        Toast.fire({
                            icon: 'error',
                            title: 'Something Error'
                        });
                        document.getElementById('notificationSound').play();
                        setTimeout(function() {
                            location.reload();
                        }, 5000);
                    }
                }
            });
        }
    }
</script>

<?php
require('footer.php');
?>