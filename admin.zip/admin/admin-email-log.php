<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="main-title" style="padding-bottom: 10px;">Admin Email Log </h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="all-admin" class="btn btn-warning btn-sm"><i class="fa-solid fa-backward"></i> Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Admin Email List</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" id="SearchInput" onkeyup="AdminLoinLogSearchFun()" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table id="AdminLogTable" class="table table-bordered  main-title text-center align-middle">
                                    <tr>
                                        <th>#</th>
                                        <th>Email</th>
                                        <th>Date</th>
                                        <th>View</th>
                                    </tr>
                                    <?php
                                    $sl = 0;
                                    if (!isset($_GET['email'])) {
                                        $ff = base64_encode('none');

                                        $data = getAdminUserEamilLog($ff);
                                    } else {
                                        $email = $_GET['email'];
                                        $data = getAdminUserEamilLog($email);
                                    }
                                    if (empty($data)) {
                                        echo "<tr>
                                                <td colspan='6' class='bg-danger text-white'>No Data Found</td>
                                            </tr>";
                                    }
                                    foreach ($data as $row) {
                                    ?>

                                        <tr>
                                            <td><?php echo $sl++; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['date']; ?></td>
                                            <td><a class="btn btn-sm btn-warning" href="view-admin-email-details?id=<?php echo base64_encode($row['id']); ?>">View</a></td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td id="NoDataFound" style="display: none;" colspan="4" class="bg-danger text-white">No Data Found</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>

</script>
<?php
require('footer.php');
?>