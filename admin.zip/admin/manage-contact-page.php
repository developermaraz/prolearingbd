<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Manage Contact Page</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <form action="">
                                <div class="row">
                                    <div class="col-md-4">
                                        <p class="main-title mb-20"><b>Image</b></p>
                                        <div style="height: 310px; border: none; box-shadow: 0px 0px 13px 0px #8b8b8b; border-radius: 20px;">
                                            <img width="100%" height="310px" style="border-radius: 20px;" src="../images/teammates/teammate-1.jpg" alt="">
                                        </div>
                                        <button class="mt-5 btn btn-sm btn-warning w-100">Image</button>
                                        <p class="main-title m-2">Supported files: <b>jpeg, jpg, png.</b> | Will be resized to: <b>600x600 px.</b></p>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="" class="main-title">Title</label>
                                            <input type="text" name="title" class="form-control border-warning" value="Get In Touch With Us">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Short Details</label>
                                            <input type="text" name="title" class="form-control border-warning" value="ichhashopping.com is a trusted virtual e-commerce marketplace. It is an online retailer that sells various products online from anywhere in Bangladesh. We have more than 25000 products. We sell them online. We have 30 days money-back guarantee service. We always work with fidelity. Thanks for staying with us.">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Phone no</label>
                                            <input type="text" name="title" class="form-control border-warning" value="+8801648837019">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Address</label>
                                            <input type="text" name="title" class="form-control border-warning" value="35/3, Mirpur,Dhaka, Bangladesh">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Email address</label>
                                            <input type="text" name="title" class="form-control border-warning" value="info@developermaraz.com.bd">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Map API</label>
                                            <input type="text" name="title" class="form-control border-warning" value="info@developermaraz.com.bd">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Email Address</label>
                                            <input type="text" name="title" class="form-control border-warning" value="AIzaSyCo_pcAdFNbTDCAvMwAD19oRTuEmb9M50c">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Longitude</label>
                                            <input type="text" name="title" class="form-control border-warning" value="0.1276">
                                        </div>
                                        <div class="form-group mt-5">
                                            <label for="" class="main-title">Latitude</label>
                                            <input type="text" name="title" class="form-control border-warning" value="51.5072">
                                        </div>
                                    </div>
                                    <button class="btn btn-warning btn-sm w-100 mt-5">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<?php
require('footer.php');
?>