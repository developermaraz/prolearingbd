<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Product Reviews</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Product Reviews</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-8">
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Categories or Subcategories Name">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="overflow-x: scroll;">
                                <table class="table table-bordered  main-title" style="text-align:center; vertical-align:middle;">
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>User</th>
                                        <th>Rating</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    <tr>
                                        <td>01</td>
                                        <td>
                                            <img src="../images/avatars/avatar-1.jpg" class="mb-3" width="50px" alt="">
                                            <p class="main-title ">Product title</p>
                                        </td>
                                        <td>Center Point</td>
                                        <td>120.00</td>
                                        <td>3</td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-danger">Pending</button>
                                        </td>
                                        <td>
                                            <a href="admin-details.php" class="btn btn-warning btn-sm" title="Restore"><i class="fa-solid fa-trash-arrow-up"></i></a>
                                        </td>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>