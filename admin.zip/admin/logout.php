<?php
session_start();
unset($_SESSION['successfullyLoginStatus']);
session_destroy();
header("location: login");
exit;
?>