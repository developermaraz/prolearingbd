/* =========================================
    *   Search Function Here 
===========================================*/
// this is a admin search function;
function searchFun() {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    let filter = document.getElementById('SearchInput').value.toUpperCase();
    let myTable = document.getElementById('AllAdminTable');
    let tr = myTable.getElementsByTagName('tr');
    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[2];
        if (td) {
            let textValue = td.textContent || td.innerHTML;
            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                document.getElementById('NoDataFound').style.display = "none";
            } else {
                tr[i].style.display = "none";
                document.getElementById('NoDataFound').style.display = "table-cell";
            }
        }
    }
}
// admin login log search function;
function AdminLoinLogSearchFun() {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    let filter = document.getElementById('SearchInput').value.toUpperCase();
    let myTable = document.getElementById('AdminLogTable');
    let tr = myTable.getElementsByTagName('tr');
    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[1];
        if (td) {
            let textValue = td.textContent || td.innerHTML;
            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                document.getElementById('NoDataFound').style.display = "none";
            } else {
                tr[i].style.display = "none";
                document.getElementById('NoDataFound').style.display = "table-cell";
            }
        }
    }
}
// This function is for Search the name in categoris page in Child Sub category table;
function SearchChildSubCategoryNameInProductCategories() {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    let filter = document.getElementById('ChildSubCategoryPCP').value.toUpperCase();
    let myTable = document.getElementById('ChildSubCategoryTablePCP');
    let tr = myTable.getElementsByTagName('tr');
    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[3];
        if (td) {
            let textValue = td.textContent || td.innerHTML;
            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                document.getElementById('NoDataFoundChildSubCategoryTablePCP').style.display = "none";
            } else {
                tr[i].style.display = "none";
                document.getElementById('NoDataFoundChildSubCategoryTablePCP').style.display = "table-cell";
            }
        }
    }
}
// This function is for Search the name in categoris page in Sub category table;
function SearchSubCategoryNameInProductCategories() {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    let filter = document.getElementById('subCategoryPCP').value.toUpperCase();
    let myTable = document.getElementById('subCategoryTablePCP');
    let tr = myTable.getElementsByTagName('tr');
    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[2];
        if (td) {
            let textValue = td.textContent || td.innerHTML;
            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                document.getElementById('NoDataFoundSubCategoryTablePCP').style.display = "none";
            } else {
                tr[i].style.display = "none";
                document.getElementById('NoDataFoundSubCategoryTablePCP').style.display = "table-cell";
            }
        }
    }
}
// This function is for Search the name in categoris page in category table;
function SearchCategoryNameInProductCategories() {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    let filter = document.getElementById('categoryPCP').value.toUpperCase();
    let myTable = document.getElementById('categoryTablePCP');
    let tr = myTable.getElementsByTagName('tr');
    for (var i = 0; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName('td')[1];
        if (td) {
            let textValue = td.textContent || td.innerHTML;
            if (textValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
                document.getElementById('NoDataFoundCategoryTablePCP').style.display = "none";
            } else {
                tr[i].style.display = "none";
                document.getElementById('NoDataFoundCategoryTablePCP').style.display = "table-cell";
            }
        }
    }
}
/* =========================================
    *   Add New Here 
===========================================*/
// this function is for Add New Admin;
function addNewAdminUser() {
    event.preventDefault();
    $(".loader-div").show();
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    var fullName = document.getElementById("AddNewFullName").value;
    var email = document.getElementById("AddNewEmail").value;
    var role = document.getElementById("AddNewRole").value;
    // check empty or not;
    if (fullName == '') {
        document.getElementById('notificationSound').play();
        $(".loader-div").hide();
        Toast.fire({
            icon: 'error',
            title: 'Full Name Is Required!'
        });
    } else if (email == '') {
        document.getElementById('notificationSound').play();
        $(".loader-div").hide();
        Toast.fire({
            icon: 'error',
            title: 'Email Is Required!'
        });
    } else if (role == '') {
        document.getElementById('notificationSound').play();
        $(".loader-div").hide();
        Toast.fire({
            icon: 'error',
            title: 'Role Is Required!'
        });
    } else {
        $.ajax({
            url: 'function/functions.php?operation_type=AddNewAdmin',
            type: 'POST',
            dataType: 'html',
            data: {
                DataName: fullName,
                DataEmail: email,
                DataRole: role
            },
            success: function (response) { // Adjust for 0-based index
                if (response === 'emailAdded') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'Already Added This Email'
                    });
                    document.getElementById('notificationSound').play();
                } else {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'success',
                        title: 'Successfully Send Request'
                    });
                    document.getElementById('notificationSound').play();
                    setTimeout(function () {
                        location.reload();
                    }, 5000);
                }
            }
        });
    }

}
// Add New Category
function addNewCategory() {
    event.preventDefault();
    $(".loader-div").show();
    var formData = new FormData();
    formData.append("image", $("#image")[0].files[0]);
    var imageInput = $("#image")[0];
    formData.append("cateName", $("#cateName").val());
    formData.append("metaTitle", $("#metaTitle").val());
    formData.append("metaDes", $("#metaDes").val());
    formData.append("metaKeywords", $("#metaKeywords").val());
    formData.append("topCate", $("#topCate").val());
    formData.append("SpeCate", $("#SpeCate").val());
    var cateName = document.getElementById("cateName").value;
    var metaTitle = document.getElementById("metaTitle").value;
    var metaDes = document.getElementById("metaDes").value;
    var metaKeywords = document.getElementById("metaKeywords").value;
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    // check image;
    if (!imageInput.files.length) {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Image Is Required!'
        });
    } else if (cateName == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Category Name Is Required!'
        });
    } else if (metaTitle == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Title Is Required!'
        });
    } else if (metaDes == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Description Is Required!'
        });
    } else if (metaKeywords == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Keywords Is Required!'
        });
    } else {
        $.ajax({
            url: "function/functions.php?operation_type=addNewCategory",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response === 'categoryNameIsAlreadyFounded') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'Already Added This Category Name'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'CategoryImageSizeDoesNotMatch') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Size Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileTypeDoesNotMatched') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Type Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileSouldBe500kb') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Should Be 500 KB'
                    });
                    document.getElementById('notificationSound').play();
                } else {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'success',
                        title: 'Successfully Added New Category'
                    });
                    document.getElementById('notificationSound').play();
                    setTimeout(function() {
                        location.reload();
                    }, 5000);
                }
            }
        });
    }
}
// Add New Sub Category
function addNewSubCategory() {
    event.preventDefault();
    $(".loader-div").show();
    var formData = new FormData();
    formData.append("image", $("#image")[0].files[0]);
    var imageInput = $("#image")[0];
    formData.append("Categroy", $("#Categroy").val());
    formData.append("cateName", $("#cateName").val());
    formData.append("metaTitle", $("#metaTitle").val());
    formData.append("metaDes", $("#metaDes").val());
    formData.append("metaKeywords", $("#metaKeywords").val());
    formData.append("topCate", $("#topCate").val());
    formData.append("SpeCate", $("#SpeCate").val());
    var Categroy = document.getElementById("Categroy").value;
    var cateName = document.getElementById("cateName").value;
    var metaTitle = document.getElementById("metaTitle").value;
    var metaDes = document.getElementById("metaDes").value;
    var metaKeywords = document.getElementById("metaKeywords").value;
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    // check image;
    if (Categroy == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Category Is Required!'
        });
    } else if (!imageInput.files.length) {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Image Is Required!'
        });
    } else if (cateName == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Sub Category Name Is Required!'
        });
    } else if (metaTitle == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Title Is Required!'
        });
    } else if (metaDes == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Description Is Required!'
        });
    } else if (metaKeywords == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Keywords Is Required!'
        });
    } else {
        $.ajax({
            url: "function/functions.php?operation_type=addNewSubCategory",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response === 'subcategoryNameIsAlreadyFounded') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'Already Added This Sub Category Name'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'subCategoryImageSizeDoesNotMatch') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Size Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileTypeDoesNotMatched') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Type Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileSouldBe500kb') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Should Be 500 KB'
                    });
                    document.getElementById('notificationSound').play();
                } else {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'success',
                        title: 'Successfully Added Sub Category'
                    });
                    document.getElementById('notificationSound').play();
                    setTimeout(function () {
                        location.reload();
                    }, 5000);
                }
            }
        });
    }
}
// Add New Sub Child Category
function addNewSubChildCategory() {
    event.preventDefault();
    $(".loader-div").show();
    var formData = new FormData();
    formData.append("image", $("#image")[0].files[0]);
    var imageInput = $("#image")[0];
    formData.append("categroy", $("#categroy").val());
    formData.append("SubCategroy", $("#SubCategroy").val());
    formData.append("cateName", $("#cateName").val());
    formData.append("metaTitle", $("#metaTitle").val());
    formData.append("metaDes", $("#metaDes").val());
    formData.append("metaKeywords", $("#metaKeywords").val());
    formData.append("topCate", $("#topCate").val());
    formData.append("SpeCate", $("#SpeCate").val());
    var categroy = document.getElementById("categroy").value;
    var SubCategroy = document.getElementById("SubCategroy").value;
    var cateName = document.getElementById("cateName").value;
    var metaTitle = document.getElementById("metaTitle").value;
    var metaDes = document.getElementById("metaDes").value;
    var metaKeywords = document.getElementById("metaKeywords").value;
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    // check image;
    if (categroy == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Category Is Required!'
        });
    } if (SubCategroy == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Sub Category Is Required!'
        });
    } else if (!imageInput.files.length) {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Image Is Required!'
        });
    } else if (cateName == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Sub Child Category Name Is Required!'
        });
    } else if (metaTitle == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Title Is Required!'
        });
    } else if (metaDes == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Description Is Required!'
        });
    } else if (metaKeywords == '') {
        $(".loader-div").hide();
        document.getElementById("notificationSound").play();
        Toast.fire({
            icon: 'error',
            title: 'Meta Keywords Is Required!'
        });
    } else {
        $.ajax({
            url: "function/functions.php?operation_type=addNewSubChildCategory",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response === 'subcategoryNameIsAlreadyFounded') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'Already Added This Sub Child Category Name'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'subCategoryImageSizeDoesNotMatch') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Size Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileTypeDoesNotMatched') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Type Is Not Match'
                    });
                    document.getElementById('notificationSound').play();
                } else if (response === 'FileSouldBe500kb') {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'error',
                        title: 'File Should Be 500 KB'
                    });
                    document.getElementById('notificationSound').play();
                } else {
                    $(".loader-div").hide();
                    Toast.fire({
                        icon: 'success',
                        title: 'Successfully Added Sub Child Category'
                    });
                    document.getElementById('notificationSound').play();
                    setTimeout(function () {
                        location.reload();
                    }, 5000);
                }
            }
        });
    }
}
/* =========================================
    *   Active-Deactive Here 
===========================================*/
// this function is for admin user active and deactive;
function activeDeactiveAdmin(id, rowIndex) {
    document.getElementById('notificationSound').play();
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    $.ajax({
        url: 'function/functions.php?operation_type=MangeAdminStatus',
        type: 'POST',
        dataType: 'html',
        data: 'adminUserId=' + id,
        success: function (response) {
            const statusButton = document.querySelectorAll("#status")[rowIndex - 1]; // Adjust for 0-based index
            if (response === 'active') {
                statusButton.className = "btn btn-sm btn-success";
                statusButton.innerHTML = "Active";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Active User'
                });
            } else {
                statusButton.innerHTML = "Inactive";
                statusButton.className = "btn btn-sm btn-danger";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Inactive User'
                });
            }
        }
    });
}
// Status Control For Product Category
function activeDeactiveProductCategory(id, rowIndex) {
    document.getElementById('notificationSound').play();
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    $.ajax({
        url: 'function/functions.php?operation_type=MangeProductCategoryStatus',
        type: 'POST',
        dataType: 'html',
        data: 'productId=' + id,
        success: function (response) {
            const statusButton = document.querySelectorAll("#CategoriesStatus")[rowIndex - 1]; // Adjust for 0-based index
            if (response === 'active') {
                statusButton.className = "btn btn-sm btn-success";
                statusButton.innerHTML = "Active";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Active Category'
                });
            } else {
                statusButton.innerHTML = "Inactive";
                statusButton.className = "btn btn-sm btn-danger";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Inactive Category'
                });
            }
        }
    });
}
// Status control for Product Sub Control
function activeDeactiveProductSubCategory(id, rowIndex) {
    document.getElementById('notificationSound').play();
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    $.ajax({
        url: 'function/functions.php?operation_type=MangeProductSubCategoryStatus',
        type: 'POST',
        dataType: 'html',
        data: 'productId=' + id,
        success: function (response) {
            const statusButton = document.querySelectorAll("#SubCategoriesStatus")[rowIndex - 1]; // Adjust for 0-based index
            if (response === 'active') {
                statusButton.className = "btn btn-sm btn-success";
                statusButton.innerHTML = "Active";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Active Sub Category'
                });
            } else {
                statusButton.innerHTML = "Inactive";
                statusButton.className = "btn btn-sm btn-danger";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Inactive Sub Category'
                });
            }
        }
    });
}
// Status control for Product Sub Child Control
function activeDeactiveProductSubChildCategory(id, rowIndex) {
    document.getElementById('notificationSound').play();
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    })
    $.ajax({
        url: 'function/functions.php?operation_type=MangeProductSubChildCategoryStatus',
        type: 'POST',
        dataType: 'html',
        data: 'productId=' + id,
        success: function (response) {
            const statusButton = document.querySelectorAll("#SubChildCategoriesStatus")[rowIndex - 1]; // Adjust for 0-based index
            if (response === 'active') {
                statusButton.className = "btn btn-sm btn-success";
                statusButton.innerHTML = "Active";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Active Sub Child Category'
                });
            } else {
                statusButton.innerHTML = "Inactive";
                statusButton.className = "btn btn-sm btn-danger";
                Toast.fire({
                    icon: 'success',
                    title: 'Successfully Inactive Sub Child Category'
                });
            }
        }
    });
}
/* =========================================
    *   Delete Item Here 
============================================*/
// This function is for delete product category
function deleteFunctionForProductCateogry(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to delete the category?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            $.ajax({
                url: 'function/functions.php?operation_type=DeleteProductCategory',
                type: 'POST',
                dataType: 'html',
                data: 'productId=' + id,
                success: function(response) {
                    if (response === 'success') {
                        $('#row_' + id).hide('slow');
                        Toast.fire({
                            icon: 'success',
                            title: 'Successfully Delete Category'
                        });
                    } else {
                        Toast.fire({
                            icon: 'error',
                            title: 'Something Problem'
                        });
                    }
                }
            });
        }
    })
}
// This function is for delete product sub category
function deleteFunctionForProductSubCateogry(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to delete the subcategory?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            $.ajax({
                url: 'function/functions.php?operation_type=DeleteProductSubCategory',
                type: 'POST',
                dataType: 'html',
                data: 'productId=' + id,
                success: function(response) {
                    if (response === 'success') {
                        $('#SubCateRow_' + id).hide('slow');
                        Toast.fire({
                            icon: 'success',
                            title: 'Successfully Delete Sub Category'
                        });
                    } else {
                        Toast.fire({
                            icon: 'error',
                            title: 'Something Problem'
                        });
                    }
                }
            });
        }
    })
}
// This function is for delete product Sub Child category
function deleteFunctionForProductSubChildCateogry(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to delete the sub child category?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            $.ajax({
                url: 'function/functions.php?operation_type=DeleteProductSubChildCategory',
                type: 'POST',
                dataType: 'html',
                data: 'productId=' + id,
                success: function (response) {
                    if (response === 'success') {
                        $('#SubChildRow_' + id).hide('slow');
                        Toast.fire({
                            icon: 'success',
                            title: 'Successfully Delete Sub Child Category'
                        });
                    } else {
                        Toast.fire({
                            icon: 'error',
                            title: 'Something Problem'
                        });
                    }
                }
            });
        }
    })
}
/* =========================================
    *   Other Code Here 
============================================*/
//  Selected Image show in div;
function display(event) {
    document.getElementById("showImg").src = URL.createObjectURL(event.target.files[0]);
}
// this function is for get sub category when select category
function getSubCategoryNameBySelectedCate() {
    var category_id = document.getElementById('categroy').value;

    $.ajax({
        type: "POST",
        url: "function/functions.php?operation_type=getSubcateNameBYCate",
        dataType: 'html',
        data: {
            category_id: category_id
        },
        success: function (data) {
            $("#SubCategroy").html(data);
        }
    });
}
