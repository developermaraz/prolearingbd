<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">Manage Subscribe Section</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <form action="">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="" class="main-title">Title</label>
                                            <input type="text" name="title" class="form-control border-warning" value="Subscribe to our newsletter to get the latest news, updates, and special offers">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button class="btn btn-warning btn-sm w-100 mt-5">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</main>
<?php
require('footer.php');
?>