<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <h2 class="main-title" style="padding-bottom: 10px;">General Settings</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">General Settings</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-3 p-1">
                                <label class="main-title">Site Title</label>
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                            <div class="col-md-3 p-1">
                            <label class="main-title">Currency</label>
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                            <div class="col-md-3 p-1">
                            <label class="main-title">Currency Symbol</label>
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">Time Zone</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Time Zone</option>
                                    <option value="">Asia/Kolkata</option>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-4 p-1">
                                <label class="main-title">Commission on Sale</label>
                                <input type="text" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                            <div class="col-md-4 p-1">
                            <label class="main-title">Site Base Color</label>
                                <input type="color" class="form-control border-danger main-nav--bg main-title" placeholder="Search Mobile / Email">
                            </div>
                            <div class="col-md-4 p-1">
                                <label class="main-title">Cash On Delivery</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-3 p-1">
                                <label class="main-title">Force Secure Password</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">Agree policy</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">User Registration</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">Force SSL</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Time Zone</option>
                                    <option value="">Asia/Kolkata</option>
                                </select>
                            </div>
                        </div>
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-3 p-1">
                                <label class="main-title">Email Verification</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">Email Notification</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">SMS Verification</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                            <div class="col-md-3 p-1">
                                <label class="main-title">SMS Notification</label>
                                <select name="" class="form-select" id="">
                                    <option value="">Select Status</option>
                                    <option value="">ON</option>
                                    <option value="">OFF</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-sm btn-warning w-100">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h2 class="main-title m-5">=> Upload Logo And Favicon</h2>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Upload Logo & Favicon</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-md-6 p-3" style="box-shadow: 0px 0px 5px 0px wheat; border-radius: 20px;">
                                <label class="main-title mb-3">Logo</label>
                                <div style="height: 310px; border: none;  border-radius: 20px;">
                                    <img width="100%" height="310px" style="border-radius: 12px;" src="../images/logos/darkLogo.png" alt="">
                                </div>
                                <button class="btn btn-sm btn-warning w-100 mt-3">Submit</button>
                            </div>
                            <div class="col-md-6 p-3" style="box-shadow: 0px 0px 5px 0px wheat; border-radius: 20px;">
                                <label class="main-title mb-3">Favicon</label>
                                <div style="height: 310px; border: none;  border-radius: 20px;">
                                    <img width="100%" height="310px" style="border-radius: 12px;" src="../images/favicon.png" alt="">
                                </div>
                                <button class="btn btn-sm btn-warning w-100 mt-3">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
require('footer.php');
?>