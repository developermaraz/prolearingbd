<?php
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="main-title" style="padding-bottom: 10px;">Add Sub Category</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="product-categories" class="btn btn-warning btn-sm"><i class="fa-solid fa-backward"></i> Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">Add Sub Category</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <form id="uploadAddCategory" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <h4 class="main-title">Select Category</h4>
                                    <select name="Categroy" class="form-select border-warning mt-3" id="Categroy">
                                        <option value="">Select Category</option>
                                        <?php
                                        $data = getAllCategoryNameandId();
                                        foreach($data as $row){
                                            
                                        ?>
                                        <option value="<?php echo base64_encode($row['id']); ?>"><?php echo $row['name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-6 align-middle">
                                    <h4 class="main-title">Category Image</h4>
                                    <input class="form-control border-warning mt-3" type="file" id="image" name="image" accept=".jpg, .jpeg, .png" onchange="display(event)">
                                    <span class="mt-3 main-title">Supported Files: <b>jpeg, jpg, png</b>. Image will be resized into <b>200x150px</b></span>
                                </div>
                                <div class="col-md-6 text-center align-middle">
                                    <div style="width:200px; height:150px; border:2px solid #ff5e00; text-align: center;">
                                        <img style="width: 200px; height:150px;" src="" alt="" id="showImg">
                                    </div>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <h4 class="main-title">Category Name</h4>
                                    <input type="text" id="cateName" name="cateName" placeholder="Category Name" class="form-control mt-2 border-warning" value="<?php if (isset($_SESSION['providedCateName']) && !empty($_SESSION['providedCateName'])) {
                                                                                                                                                                        echo $_SESSION['providedCateName'];
                                                                                                                                                                        unset($_SESSION['providedCateName']);
                                                                                                                                                                    } ?>">
                                </div>
                                <div class="col-md-6 mt-3">
                                    <h4 class="main-title">Meta Title</h4>
                                    <input type="text" id="metaTitle" name="metaTitle" placeholder="Meta Title" class="form-control mt-2 border-warning" value="<?php if (isset($_SESSION['providedmetaTitle']) && !empty($_SESSION['providedmetaTitle'])) {
                                                                                                                                                                    echo $_SESSION['providedmetaTitle'];
                                                                                                                                                                    unset($_SESSION['providedmetaTitle']);
                                                                                                                                                                } ?>">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <h4 class="main-title">Meta Description</h4>
                                    <textarea name="metaDes" id="metaDes" class="form-control border-warning mt-2" rows="5"><?php if (isset($_SESSION['providedmetaDes']) && !empty($_SESSION['providedmetaDes'])) {
                                                                                                                                echo $_SESSION['providedmetaDes'];
                                                                                                                                unset($_SESSION['providedmetaDes']);
                                                                                                                            } ?></textarea>
                                </div>
                                <div class="col-md-12 mt-3">
                                    <h4 class="main-title">Meta Keywords</h4>
                                    <input type="text" id="metaKeywords" name="metaKeywords" placeholder="Meta Keywords" class="form-control mt-2 border-warning" value="<?php if (isset($_SESSION['providedmetaKeywords']) && !empty($_SESSION['providedmetaKeywords'])) {
                                                                                                                                                                                echo $_SESSION['providedmetaKeywords'];
                                                                                                                                                                                unset($_SESSION['providedmetaKeywords']);
                                                                                                                                                                            } ?>">
                                </div>
                                <div class="col-md-12 mt-3">
                                    <button type="button" class="btn btn-sm btn-warning w-100" name="addNewCategoryBtn" onclick="addNewSubCategory()">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>



<script>
    
</script>

<?php
require('footer.php');
?>