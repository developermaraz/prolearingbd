<?php
if(!isset($_GET['id'])){
    header("Location: ../404");
}else{
    $id = base64_decode($_GET['id']);
}
require('header.php');
?>
<!-- ! Main -->
<main class="main users chart-page" id="skip-target">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="main-title" style="padding-bottom: 10px;">View Email</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="admin-email-log" class="btn btn-warning btn-sm"><i class="fa-solid fa-backward"></i> Back</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info">
                        <h5 class="main-title">View Email</h5>
                    </div>
                    <div class="card-body main-nav--bg ">
                        <?php
                        $sql = "SELECT `id`, `type`, `email`, `subject`, `text`, `date` FROM `adminlog` WHERE id = '$id'";
                        $rel = mysqli_query($connect, $sql);
                        $data = mysqli_fetch_assoc($rel);
                        ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h3><b>To:</b></h5>
                            </div>
                            <div class="col-md-12 fa-border mt-4 pt-3 pb-3">
                                <h4><?php echo $data['email']; ?></h4>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h3><b>Date:</b></h5>
                            </div>
                            <div class="col-md-12 fa-border mt-4 pt-3 pb-3">
                                <h4><?php echo $data['date']; ?></h4>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h3><b>Subject:</b></h5>
                            </div>
                            <div class="col-md-12 fa-border mt-4 pt-3 pb-3">
                                <h4><?php echo $data['subject']; ?></h4>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h3><b>Message:</b></h5>
                            </div>
                            <div class="col-md-12 fa-border mt-4 pt-3 pb-3">
                                <h4><?php echo $data['text']; ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>

</script>
<?php
require('footer.php');
?>